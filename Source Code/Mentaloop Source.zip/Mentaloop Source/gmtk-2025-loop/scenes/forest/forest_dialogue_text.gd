extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _on_enable_collision() -> void:
	pass # Replace with function body.

func _on_forest_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_forest_2_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_forest_3_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_forest_4_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_triange_girl_dialogue() -> void:
	pass # Replace with function body.
