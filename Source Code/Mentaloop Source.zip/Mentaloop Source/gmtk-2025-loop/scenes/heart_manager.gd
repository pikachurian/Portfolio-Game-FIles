extends HBoxContainer

var cur_hp = 0

func  _process(delta):
	if get_tree().get_first_node_in_group("player").player_hp != cur_hp:
		cur_hp = spawn_hearts(cur_hp, get_tree().get_first_node_in_group("player").player_hp)
		
func spawn_hearts(cur_hp, target_hp):
	#print("spawned hearts")
	var i = 0
	var hp_spawn_direction = target_hp - cur_hp
	while i < absi(hp_spawn_direction):
		if absi(hp_spawn_direction) / hp_spawn_direction > 0:
			add_child(load("res://scenes/heart.tscn").instantiate())
		else:
			get_child(0).queue_free()
		i += 1
	return target_hp
