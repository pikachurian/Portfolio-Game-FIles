extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _ready() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.scale = Vector2(1.0, 1.0)
	child.global_position = Vector2(1700, 1000)
	child.voice = "narrator_tutorial"
	child.text = ["Now  that you're back, try moving.","By the way, your shoes are equipped with spurs.", "Try ground pounding the creature to make it \nmove.", "Slay its demons by pounding its glowing weakpoints.", "Be careful maneuvering around the spikes.", "Get to work!"]
	child.connect("finished_dialogue", _on_finished_dialogue)
