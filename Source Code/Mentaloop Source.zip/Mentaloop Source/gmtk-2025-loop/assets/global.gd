extends Node

var level : int = 0

var talked_to_bruno : bool = false

var talked_to_Merryl : bool = false

var met_spamton : bool = false

var talked_to_spamton : bool = false

var spamton_escaped : bool = false

var talked_to_greg : bool = false

var broke_mirror : bool = false

var beat_game : bool = false

var levels_beat = [false, false, false, false, false, false]

var textbox : bool = false

var entering_level_from_overworld : bool = true  

var current_song = ""

var current_song_pos : float = 0.0

var player_last_direction : String = "front"

static func wave(from : float, to : float, duration : float, offset : float) -> float:
	var a4 = (to - from) * 0.5
	return from + a4 + sin((((Time.get_unix_time_from_system() / 1000) + duration * offset)/ duration) * (PI * 2)) * a4
