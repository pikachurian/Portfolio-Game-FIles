extends AnimatedSprite3D

func _ready() -> void:
	if Global.levels_beat[1]:
		$"../Sprite3D".texture = load("res://assets/sprites/hallway/hallway cleared.png")
		$"../Block/CollisionShape3D".disabled = true
		play("happy")
		$AnimatedSprite3D.queue_free()
	else:
		play("rest")
		$SquareGuy/CollisionShape3D.disabled = true
	
func _process(delta: float) -> void:
	if Global.levels_beat[1]:
		play("happy")
		$SquareGuy/CollisionShape3D.disabled = false
