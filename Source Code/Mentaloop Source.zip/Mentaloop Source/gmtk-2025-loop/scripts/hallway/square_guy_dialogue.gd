extends CanvasLayer

@export var dialogue = []

func _on_area_3d_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "denial"
	child.text = ["Not letting you pass.", "Actually, I'm going to rest while you struggle."]
	child.connect("finished_dialogue", _on_finished_dialogue)
	#child.text = "Hello there!"
	
func _on_finished_dialogue():
	Global.talked_to_bruno = 1
	print(Global.talked_to_bruno)
