extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _on_square_guy_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "denial"
	child.text = ["Thanks for helping me out!", "I've already made a path.", "Cya!"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_old_bench_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*An old bench.","It seems no one has sat on it in years."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_slightly_less_old_bench_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*An old bench.","It seems to have been sat on a slight bit.", "There is a lack of dust."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_trench_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*A deep hole scraped into the ground.", "It seems the trench was made from walking back and forth.", "Now that's determination."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_patrick_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*There's a vague shadow of something through the window.", "It seems it's bald."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_rivers_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["There's a silhouette in the distance", "It's standing in an introverted fashion."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_matt_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["There's a man in the near distance", "He's standing like he's waiting for something or someone."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_brian_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["There's a man in the window.", "He's standing with his hands in his pockets."]#"He's lounging where he stands."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_trench_side_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*A deep hole scraped into the ground.", "It seems the trench was made from walking back and forth.", "Now that's determination."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_wooden_plank_bridge_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*A bridge to cross the gap.", "It's contructed out of leftover planks and arts n' crafts glue."]
	child.connect("finished_dialogue", _on_finished_dialogue)
