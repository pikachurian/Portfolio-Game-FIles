extends Area3D

signal dialogue

var interacting : bool = false

func _on_body_entered(body: Node3D) -> void:
	interacting = true


func _on_body_exited(body: Node3D) -> void:
	interacting = false

func _process(delta: float) -> void:
	#print(interacting)
	if interacting && Input.is_action_just_pressed("interact") && !Global.textbox:
		dialogue.emit()
		monitoring = false
		interacting = false
		
func _on_dialogue():
	pass


func _on_canvas_layer_enable_collision() -> void:
	monitoring = true
	interacting = false
