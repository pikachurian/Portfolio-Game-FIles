extends Node3D

func _ready() -> void:
	Global.textbox = false
	if Global.levels_beat[1]:
		$OldBench.queue_free()
		$Trench.queue_free()
	else:
		$SlightlyLessOldBench.queue_free()
		$TrenchSide.queue_free()
		$WoodenPlankBridge.queue_free()
	$AnimationPlayer.play("enter room")


func _on_area_3d_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_up")

func exit_up():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	if Global.levels_beat[4]:
		get_tree().change_scene_to_file("res://scenes/cat room/mirror_cat_room.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/cat room/cat room.tscn")
		
func exit_right():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest.tscn")


func _on_area_3d_2_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_right")
