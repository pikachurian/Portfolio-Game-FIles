extends Area3D

signal dialogue

var interacting : bool = false

var nuh_uh : bool = false

func _on_body_entered(body: Node3D) -> void:
	interacting = true


func _on_body_exited(body: Node3D) -> void:
	interacting = false

func _process(delta: float) -> void:
	if !nuh_uh:
		if interacting:
			nuh_uh = true
			$AudioStreamPlayer2D.play()
	elif interacting && Input.is_action_just_pressed("interact") && !Global.textbox:
		dialogue.emit()
		queue_free()
func _on_dialogue():
	pass
