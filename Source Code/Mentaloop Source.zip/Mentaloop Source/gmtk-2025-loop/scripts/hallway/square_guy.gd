extends AnimatedSprite3D

@export var cutscene : bool = false

func _ready() -> void:
	play("idle")

func _physics_process(delta: float) -> void:
	if cutscene:
		return
	if $"../Player".global_position.x > 0:
		if abs($"../Player".global_position.y - global_position.y) > 0.1:
			global_position.y = lerpf(global_position.y, $"../Player".global_position.y, 0.04)
			play("walk")
			#global_position.y += 1
		else:
			play("idle")
