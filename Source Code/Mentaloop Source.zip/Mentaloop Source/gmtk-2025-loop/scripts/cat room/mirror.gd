extends AnimatedSprite3D

func _ready() -> void:
	play("default")



func _on_area_3d_body_entered(body: Node3D) -> void:
	$"../AnimationPlayer".play("mirror")
	$Area3D.queue_free()
