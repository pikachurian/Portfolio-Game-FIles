extends Node3D

@onready var animated_sprite_3d_2 = $AnimatedSprite3D2/Area3D

var tutorial_gui : bool = false

func _ready() -> void:
	$AnimatedSprite3D.play("default")
	$AnimationPlayer.play("angry cat")
	$AnimatedSprite3D4.play("interact")
	$AnimatedSprite3D3.play("bottom face button")
	animated_sprite_3d_2.body_entered.connect(interact_gui)
	
func change_scene():
	get_tree().change_scene_to_file("res://scenes/cat room/cat room.tscn")

func _process(delta):
	if Input.get_connected_joypads().size() > 0:
		$AnimatedSprite3D3.visible = true
		$AnimatedSprite3D4.visible = false
	else:
		$AnimatedSprite3D3.visible = false
		$AnimatedSprite3D4.visible = true
	if get_tree().get_first_node_in_group("overworld_player").start_level:
		tutorial_gui = false
	if tutorial_gui:
		$AnimatedSprite3D3.modulate.a = lerpf($AnimatedSprite3D3.modulate.a, 1.0, 0.1)
		$AnimatedSprite3D4.modulate.a = lerpf($AnimatedSprite3D4.modulate.a, 1.0, 0.1)
	else:
		$AnimatedSprite3D3.modulate.a = lerpf($AnimatedSprite3D3.modulate.a, 0.0, 0.1)
		$AnimatedSprite3D4.modulate.a = lerpf($AnimatedSprite3D4.modulate.a, 0.0, 0.1)

func interact_gui(area):
	tutorial_gui = true
