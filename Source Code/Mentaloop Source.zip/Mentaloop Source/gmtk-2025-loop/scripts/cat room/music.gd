extends AudioStreamPlayer3D

func _ready() -> void:
	if str(Global.current_song) == str(stream.resource_path):
		play(Global.current_song_pos)
