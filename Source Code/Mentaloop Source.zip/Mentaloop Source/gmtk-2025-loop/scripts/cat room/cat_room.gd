extends Node3D

func _ready() -> void:
	Global.textbox = false
	if Global.broke_mirror:
		var child = load("res://scenes/overworld/level bubble.tscn").instantiate()
		add_child(child)
		child.level = 5
		child.global_position.y = 0.4
		#$AnimatedSprite3D2.queue_free()
		$AnimatedSprite3D2/Area3D.queue_free()
		$AnimationPlayer.play("mirror_broken")
		$AnimationPlayer.advance(1.0)
		
	$AnimationPlayer.play("beat_cat")
		


func _on_area_3d_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("switch rooms")
	
func switch_rooms():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	if Global.talked_to_bruno:
		get_tree().change_scene_to_file("res://scenes/hallway/angry_hallway.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/hallway/hallway.tscn")

func create_mirror_level():
	Global.broke_mirror = true
	var child = load("res://scenes/overworld/level bubble.tscn").instantiate()
	add_child(child)
	child.level = 5
	child.global_position.y = 0.4
