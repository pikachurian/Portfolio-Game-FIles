extends AudioStreamPlayer3D

func play_glass_break_sound():
	play()
