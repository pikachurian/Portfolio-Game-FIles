extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _on_cat_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "none"
	child.text = ["Meow."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_bed_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*It's your bed."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_posters_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*Three posters on the wall.", "One reads THE PHANTOM THIEVES.", "The middle poster has the title, THE THING.", "The last poster reads THE MIND FIXSPLORERS."]
	child.connect("finished_dialogue", _on_finished_dialogue)
	
func _on_chair_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*Someone positioned the chair towards the window.", "Probably to enjoy the sunset."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_enable_collision() -> void:
	pass # Replace with function body.
