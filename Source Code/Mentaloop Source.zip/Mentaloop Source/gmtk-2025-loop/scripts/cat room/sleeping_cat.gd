extends AnimatedSprite3D

func _ready() -> void:
	play("sleeping cat")
