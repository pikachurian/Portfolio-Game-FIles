extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _on_enable_collision() -> void:
	pass # Replace with function body.

func _on_triange_girl_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "anger"
	child.text = ["Urgh! It's so frustrating!", "After being held responsible again for the key to the shop,", "HE takes it.  AGAIN!", "Every time I try to stay calm, I get stuck in a loop of anger. Ugh!", "Hey, you.  Can you help me out?!"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_less_angry_triange_girl_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "anger"
	child.text = ["Where is that little -","Hey! HE's hiding somewhere in the forest!", "Just the thought of it makes me angry again!", "RRRMGH!"]
	child.connect("finished_dialogue", _on_finished_dialogue)
