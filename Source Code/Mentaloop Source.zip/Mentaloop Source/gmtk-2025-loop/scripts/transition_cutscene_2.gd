extends Node2D

func _ready() -> void:
	$Sprite2D/Sprite2D3.texture = load("res://assets/sprites/level bubbles/level " + str(Global.level) + ".png")
	$Sprite2D/AnimatedSprite2D2.play("default")
	$Sprite2D2/AnimatedSprite2D.play("default")
	$AnimationPlayer.play("walking")

func change_scene():
	get_tree().change_scene_to_file("res://scenes/levels/level_" + str(Global.level) + ".tscn")
