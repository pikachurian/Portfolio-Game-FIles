extends Sprite3D

func _process(delta: float) -> void:
	global_rotation.z = 0
	#global_position.x = $"../Camera3D".global_position.x
	#global_position.y = $"../Camera3D".global_position.y
	#global_position.z = $"../Camera3D".global_position.z
