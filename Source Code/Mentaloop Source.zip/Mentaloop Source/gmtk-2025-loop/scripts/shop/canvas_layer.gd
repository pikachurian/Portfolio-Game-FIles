extends CanvasLayer

signal finished_dialogue

signal enable_collision

signal greg_depressed

var greg_fire : bool = false

func _on_finished_dialogue():
	if greg_fire:
		greg_depressed.emit()
	else:
		enable_collision.emit()

func _on_enable_collision() -> void:
	pass # Replace with function body.

func _on_skateboard_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	greg_fire = false
	child.voice = "narrator"
	child.text = ["*It looks like someone tried a skateboard.", "And failed."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_greg_dialogue_dialogue() -> void:
	if Global.levels_beat[4]:
		var child = load("res://scenes/overworld/textbox.tscn").instantiate()
		add_child(child)
		child.voice = "greg"
		greg_fire = false
		child.text = ["Hey kid. You've helped me more than enough.", "It's time for you to better yourself.", "Now go home.", "..."]
		child.connect("finished_dialogue", _on_finished_dialogue)
	else:
		var child = load("res://scenes/overworld/textbox.tscn").instantiate()
		add_child(child)
		greg_fire = true
		child.voice = "greg"
		child.text = ["Hey, sorry. The shop's closed.", "I don't feel like selling anything today.", "Just leave me be."]
		child.connect("finished_dialogue", _on_finished_dialogue)


func _on_left_shelf_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	greg_fire = false
	child.voice = "narrator"
	child.text = ["*There are various items lined up on the shelf.", "They seem like the old man collected them."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_right_shelf_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	greg_fire = false
	child.voice = "narrator"
	child.text = ["*The items on the shelfs are covered in dust.", "The prices on the items range from $80 - $400.", "...Maybe that's why..."]
	child.connect("finished_dialogue", _on_finished_dialogue)
