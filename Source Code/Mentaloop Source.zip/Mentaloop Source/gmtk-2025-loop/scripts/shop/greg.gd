extends AnimatedSprite3D

func _ready() -> void:
	if Global.levels_beat[4]:
		play("default")
		$AnimatedSprite3D.queue_free()
	elif Global.talked_to_greg:
		play("fire")
		$GregDialogue.queue_free()
	else:
		play("default")
		$AnimatedSprite3D.queue_free()
