extends Node3D

func _ready() -> void:
	Global.textbox = false
	$AnimationPlayer.play("enter_room")
	
func greg_now_fire():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	Global.talked_to_greg = true
	get_tree().change_scene_to_file("res://scenes/shop/shop.tscn")

func exit_room():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_up_right.tscn")

func _on_down_exit_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_room")
