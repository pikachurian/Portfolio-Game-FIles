extends AudioStreamPlayer3D

func _ready() -> void:
	if Global.levels_beat[4]:
		stream = load("res://assets/songs/greg_room.wav")
	else:
		stream = load("res://assets/songs/greg_room_sad.wav")
	if str(Global.current_song) == str(stream.resource_path):
		play(Global.current_song_pos)
	else:
		play()
