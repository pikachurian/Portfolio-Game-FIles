extends Area3D

signal dialogue

var interacting : bool = false

func _on_body_entered(body: Node3D) -> void:
	interacting = true


func _on_body_exited(body: Node3D) -> void:
	interacting = false

func _process(delta: float) -> void:
	#print(interacting)
	if interacting && Input.is_action_just_pressed("interact") && !Global.textbox:
		dialogue.emit()
		$CollisionShape3D.disabled = true
		interacting = false
		
func _on_dialogue():
	pass


func _on_canvas_layer_enable_collision() -> void:
	$CollisionShape3D.disabled = false


func _on_timer_timeout() -> void:
	$CollisionShape3D.disabled = false


func _on_canvas_layer_greg_depressed() -> void:
	$"../../AnimationPlayer".play("greg_fire")
