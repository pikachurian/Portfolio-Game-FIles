extends LoopActor

enum PlayerState {MAIN, GROUND_POUND, SWITCH_SIDE, DEAD, LEVEL_WON}

var state : PlayerState = PlayerState.MAIN
@export var start_state : PlayerState = PlayerState.MAIN
var player_hp : int = 2

var physics_process_delta : float = 0.1

var move_speed : float = 5.0
var jump_speed : float = 13.0#10.0 #15
var gravity : float = 50.0#50

var is_grounded : bool = false
var on_dragon : bool = false
var dragon_progress_ratio_offset : float = 0.0
var dragon_radius : float = 0.3

var custom_velocity : Vector3 = Vector3.ZERO
var progress_delta : float = 0.0
var v_offset_delta : float = 0.0

#buffer for ground/dragon detection
var path_ground_buffer : float = 0.01

#jump stuff
#bad dog jump
var can_jump_tick : float = 0.0
var can_jump_time : float = 0.15#0.125
#jump buffer
var jump_buffer_tick = 0.0
var jump_buffer_time = 0.08

#camera stuff
var my_rotation : float = 0.0
var move_camera_to_player : bool = false
var camera_follow_lerp_alpha : float = 0.03#0.05
var camera_start_follow_dist : float = 1.0
var camera_end_follow_dist : float = 0.8#0.1
var camera_z_target : float = 34.0
var is_camera_zoomed_out : bool = false
@onready var camera_out_target : Node3D = get_tree().get_first_node_in_group("camera_out_target")

#var camera_follow_angle_speed : float = 1

#collisions
var area_colliding : bool = false

var sprite_dir : int = 1
var just_landed : bool = false

#ground_pound
var gp_speed : float = 30.0
signal finished_ground_pound

#switching dragon sides
@onready var previous_loop_side : int = loop_side
var hit_switch : Object = null
var switch_side_speed : float = 3.0#5.0#not used
#var switch_lerp_alpha : float = 0.2
var switch_side_tick : float = 0.0

#respawning
@onready var player_respawn = get_tree().get_first_node_in_group("player_respawn")
var has_set_first_respawn : bool = false
signal player_respawn_signal

#death
signal player_died

#audio
var walk_sound_tick : float = 0.0
var walk_sound_time_min : float = 0.3
var walk_sound_time_max : float = 0.3
@onready var walk_sounds : Array = $CollisionArea/Audio/Walk.get_children()
@onready var space_walk_sounds : Array = $CollisionArea/Audio/SpaceWalk.get_children()
@onready var jump_sound = $CollisionArea/Audio/Jump
@onready var land_sound = $CollisionArea/Audio/Land
@onready var kick_sound = $CollisionArea/Audio/Kick
@onready var weakpoint_sound = $CollisionArea/Audio/Weakpoint
@onready var leave_level_sound = $CollisionArea/Audio/LeaveLevel


@onready var camera : Camera3D = get_tree().get_first_node_in_group("camera")
@onready var sprite : AnimatedSprite3D = $CollisionArea/AnimatedSprite3D
@onready var character = $CharacterBody3D
@onready var camera_target = $CollisionArea/CameraTarget#$CameraTarget
@onready var collision_area = $CollisionArea
#@onready var left_ray = $CollisionArea/UpperHRays/LeftRay #not used now I think
#@onready var right_ray = $CollisionArea/UpperHRays/RightRay #not used now I think
@onready var down_rays = $CollisionArea/DownRays.get_children()
@onready var up_rays = $CollisionArea/UpRays.get_children()
@onready var right_rays = $CollisionArea/RightRays.get_children()
@onready var left_rays = $CollisionArea/LeftRays.get_children()
@onready var animation_player = $CollisionArea/AnimationPlayer
@onready var hit_box = $CollisionArea/HitBox
@onready var snake_ground = get_tree().get_first_node_in_group("snake_ground")

func _ready():
	#my_rotation = rotation.x
	progress_ratio_offset = progress_ratio
	dragon_progress_ratio_offset = progress_ratio
	snake_ground.level_beaten.connect(_on_level_beaten)
	state = start_state

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("title_back"):
		get_tree().change_scene_to_file("res://scenes/title/title_screen.tscn")

func _physics_process(delta):
	physics_process_delta = delta
	match state:
		PlayerState.MAIN:
			state_main(delta)
		PlayerState.GROUND_POUND:
			state_ground_pound(delta)
		PlayerState.SWITCH_SIDE:
			state_switch_side(delta)
	#flip character to match loop side
	update_loop_side_rotation()
	
	#set first player respawn
	if has_set_first_respawn == false:
		has_set_first_respawn = true
		set_player_respawn()
		
	#debug
	#if Input.is_key_pressed(KEY_0):
		#hit()


func state_main(delta : float) -> void:
	#ground_pound
	if Input.is_action_just_pressed("ground_pound") && is_grounded == false:
		change_state(delta, PlayerState.GROUND_POUND)
		return
	
	#update grounded
	update_grounded()

	#update gravity
	update_gravity(delta)
	
	#walking
	var h_input : float = Input.get_axis("move_left", "move_right")
	progress_delta = h_input * move_speed * loop_side
	
	#walking sounds
	if h_input && is_grounded == true:
		if walk_sound_tick <= 0.0:
			var audio_player = space_walk_sounds[randi_range(0, space_walk_sounds.size()-1)]
			audio_player.play()
			walk_sound_tick = randf_range(walk_sound_time_min, walk_sound_time_max)
		else:
			walk_sound_tick -= delta
	else:
		walk_sound_tick = 0.0
	
	#jumping
	if Input.is_action_just_pressed("jump"):
		jump_buffer_tick = jump_buffer_time

	if can_jump_tick > 0 && jump_buffer_tick > 0:
		jump_buffer_tick = 0
		v_offset_delta = jump_speed * loop_side
		sprite.play("jump")
		jump_sound.play()#jump sound
		
	#variable jump
	if loop_side == 1:
		if v_offset_delta > 0 && Input.is_action_pressed("jump") == false:
			v_offset_delta = min(v_offset_delta, jump_speed / 4)
	elif loop_side == -1:
		if v_offset_delta < 0 && Input.is_action_pressed("jump") == false:
			v_offset_delta = max(v_offset_delta, -jump_speed / 4)
	
	
	move_and_collide(delta)
	
	#camera movement
	update_camera(delta)
	
	#update sprite dir
	update_sprite_dir(h_input)
	
	#decrease timers
	if is_grounded == false:
		can_jump_tick -= delta
		
	jump_buffer_tick -= delta
	
	#animation
	if sprite_dir == 1:
		sprite.flip_h = false
	else:
		sprite.flip_h = true
		
	if sprite.animation != "jump":
			if h_input:
				sprite.play("run")
			elif sprite.animation == "land":
				if sprite.frame_progress == 1.0:
					sprite.play("idle")
			else:
				sprite.play("idle")

func state_ground_pound(delta : float) -> void:
	var collisions = move_and_collide(delta)
	push_out_of_walls(delta, right_rays, true)
	push_out_of_walls(delta, left_rays, false)
	update_camera(delta)
	if collisions.collide_down != null || abs(v_offset) <= dragon_radius + path_ground_buffer:
		var cols = collision_area.get_overlapping_areas()
		var dont_emit_ground_pound_signal : bool = false
		if cols != null:
			for col in cols:
				if col.is_in_group("side_switch"):
					hit_switch = col.get_parent()
					change_state(delta, PlayerState.SWITCH_SIDE)
					return
				elif col.is_in_group("weak_point"):
					col.get_parent().damage()
					dont_emit_ground_pound_signal = true
					weakpoint_sound.play()
		#dragon reacts if hit directly
		if collisions.collide_down == null && dont_emit_ground_pound_signal == false:
			emit_signal("finished_ground_pound")
			
		change_state(delta, PlayerState.MAIN)

func state_switch_side(delta : float) -> void:
	if switch_side_tick < 1.0:#abs((dragon_radius * loop_side) - v_offset) > 0.01:
		switch_side_tick += delta * switch_side_speed
		#v_offset += switch_side_speed * delta * loop_side
		v_offset = lerp(v_offset, dragon_radius * loop_side, switch_side_tick)#switch_lerp_alpha)
		camera.global_rotation.z = lerp(camera.global_rotation.z, camera_target.global_rotation.z * loop_side, switch_side_tick * 0.2)
	else:
		change_state(delta, PlayerState.MAIN)
				
func change_state(delta : float, new_state : PlayerState) -> void:
	#BANDAGE FIX
	if state == PlayerState.LEVEL_WON:
		return
	
	#leaving state code
	match state:
		PlayerState.MAIN:
			update_grounded()
			update_gravity(delta)
			move_and_collide(delta)
			update_camera(delta)
			
		PlayerState.GROUND_POUND:
			kick_sound.play()
	
	state = new_state
	
	#entering state code
	match state:
		PlayerState.MAIN:
			pass
		PlayerState.GROUND_POUND:
			sprite.play("strike")
			v_offset_delta = -gp_speed * loop_side
		PlayerState.SWITCH_SIDE:
			previous_loop_side = loop_side
			loop_side *= -1
			progress = hit_switch.progress
			switch_side_tick = 0.0
		PlayerState.LEVEL_WON:
			print("Player Winner!")
			collision_area.disable_mode = collision_area.DISABLE_MODE_REMOVE
			leave_level_sound.play()


#uses progress_delta for h movement and v_offset_delta for v
func move_and_collide(delta : float) -> Dictionary:
	var output_dictionary = {
		"collide_left" : null,
		"collide_right" : null,
		"collide_up" : null,
		"collide_down" : null
	}
	
	#collisions and applying movement
	change_my_progress(progress_delta * delta)#progress += progress_delta * delta
	
	#check left collisions
	if handle_h_collisions(delta, left_rays) != null:
		output_dictionary.collide_left = true#handle_h_collisions(delta, left_ray)
				
	#check right collisions
	if handle_h_collisions(delta, right_rays) != null:
		output_dictionary.collide_right = true#handle_h_collisions(delta, right_ray)
	
	#push out of walls
	push_out_of_walls(delta, right_rays, true)
	push_out_of_walls(delta, left_rays, false)
	
	#check v collisions
	v_offset += v_offset_delta * delta
	
	#check down collision
	if v_offset_delta < 0:
		output_dictionary.collide_down = handle_v_collisions(delta, down_rays)
	
	#push out of floor
	if is_ray_v_collection_colliding(down_rays):
		output_dictionary.collide_down = ray_v_collection_get_collider(down_rays)
		while is_ray_v_collection_colliding(down_rays):
			v_offset += 0.01 * loop_side
			ray_collection_force_update(down_rays)
			
	if loop_side == 1:		
		if v_offset <= dragon_radius * loop_side:
			output_dictionary.collide_down = ray_v_collection_get_collider(down_rays)
			v_offset = dragon_radius * loop_side
	elif loop_side == -1:
		if v_offset >= dragon_radius * loop_side:
			output_dictionary.collide_down = ray_v_collection_get_collider(down_rays)
			v_offset = dragon_radius * loop_side
		
	#check up collision
	if v_offset_delta > 0:
		output_dictionary.collide_up = handle_v_collisions(delta, up_rays)
	
	return output_dictionary

#update rotation to match loop side
func update_loop_side_rotation() -> void:
	if loop_side == 1:
		collision_area.rotation.z = 0
	else:
		collision_area.rotation.z = deg_to_rad(180)

#and on_dragon lol
func update_grounded() -> void:
	if loop_side == 1:
		if v_offset <= dragon_radius + path_ground_buffer || is_ray_v_collection_colliding(down_rays, -0.05 * loop_side):
			if is_grounded == false:
				if v_offset <= path_ground_buffer:
					on_dragon = true
				v_offset_delta = 0.0
				set_grounded(true)
		else:
			set_grounded(false)
		
		if v_offset <= dragon_radius + path_ground_buffer:
			on_dragon = true
		else:
			on_dragon = false
	elif loop_side == -1:
		if v_offset >= (dragon_radius + path_ground_buffer) * loop_side || is_ray_v_collection_colliding(down_rays, -0.05 * loop_side):
			if is_grounded == false:
				if v_offset <= path_ground_buffer:
					on_dragon = true
				v_offset_delta = 0.0
				set_grounded(true)
		else:
			set_grounded(false)
		
		if v_offset >= (dragon_radius + path_ground_buffer) * loop_side:
			on_dragon = true
		else:
			on_dragon = false
	

func update_gravity(delta : float) -> void:
	if !is_grounded:
		v_offset_delta -= gravity * delta * loop_side
	else:
		v_offset_delta = 0.0

func update_sprite_dir(h_input : float) -> void:
	if h_input != 0:
		sprite_dir = sign(h_input) * loop_side

func update_camera(delta : float) -> void:
	var camera_pos_target : Vector3 = camera_target.global_position
	camera_pos_target.z = camera_z_target
	var camera_rot_target : float = camera_target.global_rotation.z * loop_side
	var sfx_bus_volume_target : float = 0.0
	
	#zooming out/in
	if Input.is_action_just_pressed("zoom_out"):
		is_camera_zoomed_out = !is_camera_zoomed_out
		
	if is_camera_zoomed_out == true:
		camera_pos_target = camera_out_target.global_position
		
		if Global.level != 5:
			camera_rot_target = Vector2(camera_pos_target.x, camera_pos_target.y).angle_to_point(Vector2(global_position.x, global_position.y)) + 1.8 * loop_side
		
		camera_pos_target.z = lerp(camera_pos_target.z, clamp(Vector2(global_position.x, global_position.y).distance_to(Vector2(camera_pos_target.x, camera_pos_target.y)) * 5.0, 60.0, 120.0 ), 0.8)
		sfx_bus_volume_target = -70.0
	
	AudioServer.set_bus_volume_db(0, lerp(AudioServer.get_bus_volume_db(1), sfx_bus_volume_target, 0.1))
	#camera.global_position.x = lerp(camera.global_position.x, -camera_target.global_position.z, 0.1)
	camera.global_position.x = lerp(camera.global_position.x, camera_pos_target.x, 0.1)#camera_target.global_position.x, 0.1)
	camera.global_position.y = lerp(camera.global_position.y, camera_pos_target.y, 0.1)#camera_target.global_position.y, 0.1)
	camera.global_rotation.z = camera_rot_target#camera_target.global_rotation.z * loop_side
	
	camera.global_position.z = lerp(camera.global_position.z, camera_pos_target.z, 0.1)# camera_z_target, 0.1)
	#region
	#camera movement
	#if move_camera_to_player == false && abs(my_rotation - camera.rotation.z) >= camera_start_follow_dist:
		##move_camera_to_player = true
	#
	#if move_camera_to_player:
		#camera.rotation.z = lerp(camera.rotation.z, my_rotation, camera_follow_lerp_alpha)
		#if abs(my_rotation - camera.rotation.z) <= camera_end_follow_dist:
			#move_camera_to_player = false
	#camera.global_rotation.z = lerp(camera.global_rotation.z, camera_target.global_rotation.z, camera_follow_lerp_alpha)
	#camera.transform.basis.z = camera_target.transform.basis.z
	
	
	#var rot_dir : float = sign(camera_target.global_rotation.z - camera.global_rotation.z)
	#camera.global_rotation.z += rot_dir * camera_follow_angle_speed * delta
	#endregion

func set_grounded(new_grounded : bool) -> void:
	if new_grounded == true:
		sprite.play("land")
		can_jump_tick = can_jump_time
		land_sound.play()
	is_grounded = new_grounded

func push_out_of_walls(delta : float, ray_collection : Array, check_right_wall : bool) -> void:
	var dir : int = 1
	if check_right_wall == false:
		dir = -1
	ray_collection_force_update(ray_collection)
	if is_ray_h_collection_colliding(ray_collection):
		while is_ray_h_collection_colliding(ray_collection):
			change_my_progress(-0.01 * dir)#progress -= 0.01
			ray_collection_force_update(ray_collection)

#the floor is the dragon, below is relative to loop_side
func is_below_floor() -> bool:
	if loop_side == 1:
		if v_offset < dragon_radius * loop_side:
			return true
	elif loop_side == -1:
		if v_offset > dragon_radius * loop_side:
			return true
	return false

#returns true if collision
func handle_h_collisions(delta : float, ray_collection : Array) -> Object:
	var output : Object = null
	ray_collection_force_update(ray_collection)#ray.force_raycast_update()
	if is_ray_h_collection_colliding(ray_collection):
		output = ray_h_collection_get_collider(ray_collection)
		change_my_progress(-1 * (progress_delta * delta))#progress -= progress_delta * delta
		ray_collection_force_update(ray_collection)
		while is_ray_h_collection_colliding(ray_collection) == false:
			var last_progress : float = progress
			change_my_progress(sign(progress_delta) * 0.1)#progress += sign(progress_delta) * 0.1
			ray_collection_force_update(ray_collection)
			if is_ray_h_collection_colliding(ray_collection):
				set_my_progress(last_progress)#progress = last_progress
				progress_delta = 0.0
				break
				
	return output

#returns true if collision
func handle_v_collisions(delta : float, ray_collection : Array) -> Object:
	var output : Object = null
	ray_collection_force_update(ray_collection)
	if is_ray_v_collection_colliding(ray_collection):
		output = ray_v_collection_get_collider(ray_collection)
		v_offset -= v_offset_delta * delta
		ray_collection_force_update(ray_collection)
		while is_ray_v_collection_colliding(ray_collection) == false:
			var last_offset : float = v_offset
			v_offset += sign(v_offset_delta) * 0.01
			ray_collection_force_update(ray_collection)
			if is_ray_v_collection_colliding(ray_collection):
				if sign(v_offset_delta) == -1 * loop_side: #moving down
					set_grounded(true)
				v_offset = last_offset
				v_offset_delta = 0.0
				ray_collection_force_update(ray_collection)
				break
				
	return output
	
func ray_collection_force_update(collection : Array) -> void:
	for ray in collection:
		ray.force_raycast_update()
		
func is_ray_v_collection_colliding(collection : Array, offset : float = 0) -> bool:
	var result : bool = false
	var prev_v_offset = v_offset
	v_offset += offset
	ray_collection_force_update(collection)
	for ray in collection:
		if ray.is_colliding():
			result = true
	v_offset = prev_v_offset
	ray_collection_force_update(collection)
	return result
	
func is_ray_h_collection_colliding(collection : Array, offset : float = 0) -> bool:
	var result : bool = false
	var prev_progress = progress
	change_my_progress(offset)#progress += offset
	ray_collection_force_update(collection)
	for ray in collection:
		if ray.is_colliding():
			result = true
	set_my_progress(prev_progress)#progress = prev_progress
	ray_collection_force_update(collection)
	return result

func ray_v_collection_get_collider(collection : Array, offset : float = 0) -> Object:
	var result : Object = null
	var prev_v_offset = v_offset
	v_offset += offset
	ray_collection_force_update(collection)
	for ray in collection:
		if ray.is_colliding():
			result = ray.get_collider()
	v_offset = prev_v_offset
	ray_collection_force_update(collection)
	return result
	
func ray_h_collection_get_collider(collection : Array, offset : float = 0) -> Object:
	var result : Object = null
	var prev_progress = progress
	progress += offset
	ray_collection_force_update(collection)
	for ray in collection:
		if ray.is_colliding():
			result = ray.get_collider()
	progress = prev_progress
	ray_collection_force_update(collection)
	return result
	
func set_player_respawn() -> void:
	player_respawn.progress = progress
	player_respawn.v_offset = v_offset
	player_respawn.loop_side = loop_side
	
	#region Dragon Stuff
	player_respawn.dragon_progress_target = snake_ground.dragon_progress_target
	player_respawn.dragon_formation_on = snake_ground.dragon_formation_on
	player_respawn.dragon_formation_loops = snake_ground.dragon_formation_loops
	player_respawn.dragon_progress_ratio = snake_ground.dragon_progress_ratio
	#endregion
	
func respawn() -> void:
	#reset HP
	player_hp = 2
	#region move dragon
	snake_ground.dragon_progress_target = player_respawn.dragon_progress_target
	snake_ground.dragon_formation_loops = player_respawn.dragon_formation_loops
	snake_ground.dragon_formation_on = player_respawn.dragon_formation_on
	var target_change : float = player_respawn.dragon_progress_target - snake_ground.dragon_progress_ratio
	snake_ground.rotate_dragon(1.0, target_change)
	snake_ground.dragon_progress_ratio = player_respawn.dragon_progress_ratio
	#endregion
	
	set_my_progress(player_respawn.progress)#progress = player_respawn.progress
	v_offset = player_respawn.v_offset
	loop_side = player_respawn.loop_side
	
	if state != PlayerState.MAIN:
		sprite.play("idle")
		state = PlayerState.MAIN
		
	emit_signal("player_respawn_signal")
	
func hit() -> void:
	if state != PlayerState.DEAD && state != PlayerState.LEVEL_WON:
		#check if player still has hp
		if player_hp == 1:
			emit_signal("player_died")
			state = PlayerState.DEAD
			animation_player.play("dead")
			get_tree().get_first_node_in_group("camera").player_gameover()
			$DeadSound.play()
		else:
			print("enum " + str(state) + " " + str(PlayerState.LEVEL_WON))
			animation_player.play("hurt")
			$HurtSound.play()
		player_hp -= 1
	
func set_my_progress(value : float) -> void:
	var amount : float = value - progress
	change_my_progress(amount)
	#progress = value
	#progress_ratio_offset = progress_ratio

	
func change_my_progress(amount : float) -> void:
	progress += amount
	dragon_progress_ratio_offset += progress  / get_parent().curve.get_baked_length()
	


func billboard() -> void:
	sprite.look_at(camera.global_position)


func _on_collision_area_body_entered(body):
	area_colliding = true


func _on_collision_area_body_exited(body):
	area_colliding = false


func _on_hit_box_area_entered(area):
	if area.is_in_group("hazard"):
		if state != PlayerState.DEAD && state != PlayerState.LEVEL_WON:
			hit()
		
func _on_level_beaten() -> void:
	if state != PlayerState.LEVEL_WON:
		change_state(physics_process_delta, PlayerState.LEVEL_WON)
