extends Node2D

func _ready() -> void:
	$Sprite2D/Sprite2D4.texture = load("res://assets/sprites/level bubbles/level " + str(Global.level) + ".png")
	$Sprite2D2/Sprite2D4.texture = load("res://assets/sprites/level bubbles/level " + str(Global.level) + ".png")
	$Camera2D/AnimatedSprite2D2.play("player_" + Global.player_last_direction)
	#$Sprite2D/AnimatedSprite2D2.set_animation("right")
	$Sprite2D/AnimatedSprite2D2.play("default")
	$Sprite2D2/AnimatedSprite2D.play("default")
	$AnimationPlayer.play("walking")

func change_scene():
	get_tree().change_scene_to_file("res://scenes/levels/level_" + str(Global.level) + ".tscn")
