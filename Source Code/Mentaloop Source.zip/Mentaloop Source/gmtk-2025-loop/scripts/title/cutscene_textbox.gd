extends AnimatedSprite2D

var button_showing : bool = false

func _on_node_2d_show_button() -> void:
	button_showing = true
	
func _process(delta: float) -> void:
	if button_showing:
		modulate.a = lerpf(modulate.a, 1.0, 0.1)
	else:
		modulate.a = lerpf(modulate.a, 0.0, 0.1)


func _on_node_2d_hide_button() -> void:
	button_showing = false
