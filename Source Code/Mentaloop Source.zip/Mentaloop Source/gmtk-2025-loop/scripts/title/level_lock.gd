extends Sprite2D

@export var level : int = 0

func _ready() -> void:
	if Global.levels_beat[level]:
		queue_free()
