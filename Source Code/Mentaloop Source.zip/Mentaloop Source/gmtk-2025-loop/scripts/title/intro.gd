extends Node3D

func _ready() -> void:
	$AnimatedSprite3D.play("default")
	$AnimationPlayer.play("INTRO")
	$AnimatedSprite3D2.play("default")
	$AnimationPlayer.speed_scale = 1.0
	$AnimatedSprite3D.speed_scale = 1.0
	$AnimatedSprite3D2.speed_scale = 1.0

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("speed up"):
		$AnimationPlayer.speed_scale = 4.0
		$AnimatedSprite3D.speed_scale = 4.0
		$AnimatedSprite3D2.speed_scale = 4.0
	if Input.is_action_just_released("speed up"):
		$AnimationPlayer.speed_scale = 1.0
		$AnimatedSprite3D.speed_scale = 1.0
		$AnimatedSprite3D2.speed_scale =  1.0

func go_to_title_screen():
	get_tree().change_scene_to_file("res://scenes/title/title_screen.tscn")
