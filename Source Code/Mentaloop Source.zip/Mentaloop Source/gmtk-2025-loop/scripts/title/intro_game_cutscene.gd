extends Node2D

var text_progression : int = 0

var text = ["\"If you can hear me, please respond to my voice.\"", "\"Good! You had us all worried for a moment there.\"", "\"You should be able to handle this task.\"", "\"Remember, you are the visionary.\"", "\"Now go back into its mind and get the job done!\""]#["If you can hear me, please respond to my voice.", "Good! You had us all worried for a moment there.", "What we do relies on your abilities to continue.  Who know's what would have happen if you died.", "It's just a cat.  You should be able to handle this task.", "Now go back into it's mind and get the job done!"]#["Hello there.", "Allow us to introduce ourselves."]

signal show_button

signal hide_button

func _ready() -> void:
	#print(Input.get_connected_joypads())
	$AnimatedSprite2D.play("bottom face button")
	$AnimatedSprite2D.modulate.a = 0.0
	$AnimatedSprite2D2.play("interact")
	$AnimatedSprite2D2.modulate.a = 0.0
	$RichTextLabel.visible_characters = 0
	$RichTextLabel.text = text[0]
	$Timer.wait_time = 0.06
	$Timer.paused = false
	$Timer.start()

func _process(delta: float) -> void:
	if Input.get_connected_joypads().size() > 0:
		$AnimatedSprite2D.visible = true
		$AnimatedSprite2D2.visible = false
	else:
		$AnimatedSprite2D.visible = false
		$AnimatedSprite2D2.visible = true
	if Input.is_action_just_pressed("interact") && $RichTextLabel.visible_ratio == 1:
		hide_button.emit()
		if text_progression == text.size() - 1:
			$AnimationPlayer.play("go to tutorial")
			return
		text_progression += 1
		$RichTextLabel.text = text[text_progression]
		$RichTextLabel.visible_characters = 0
		$Timer.paused = false
		$Timer.start()
	if Input.is_action_pressed("speed up"):
		$Timer.wait_time = 0.01
	else:
		$Timer.wait_time = 0.06

func _on_timer_timeout() -> void:
	if $RichTextLabel.visible_ratio == 1:
		show_button.emit()
		$Timer.paused = true
		return
	if $Timer.wait_time == 0.06 && ![" ", "\"", ",", ".", "!", "?"].has(text[text_progression][$RichTextLabel.visible_characters]):#text[text_progression][$RichTextLabel.visible_characters] != " " && text[text_progression][$RichTextLabel.visible_characters] != "\"" && text[text_progression][$RichTextLabel.visible_characters] != "," && text[text_progression][$RichTextLabel.visible_characters] != ".":
		$AnimatedSprite2D2/AudioStreamPlayer2D.play()
	$RichTextLabel.visible_characters += 1
	
	
func go_to_tutorial():
	get_tree().change_scene_to_file("res://scenes/cat room/angry cat room.tscn")
