extends Node3D

var title_screen_pos = -1

var title_pre_pos = -1

@export var starting_game : bool = false

func _ready() -> void:
	Global.textbox = false
	$AnimationPlayer.play("enter_title")
	$Background3/AnimatedSprite2D.play("nothing")
	if !Global.beat_game:
		$Background2/Star.queue_free()

func _process(delta: float) -> void:
	if starting_game:
		return
	if Input.is_action_just_pressed("move_down"):
		$AudioStreamPlayer2D.play()
		title_screen_pos += 1
		title_screen_pos = clampf(title_screen_pos, 0, 3)
		#if title_screen_pos == -1:
			#title_screen_pos = 0
		button_animation(title_screen_pos)
	if Input.is_action_just_pressed("move_up"):
		$AudioStreamPlayer2D.play()
		title_screen_pos -= 1
		title_screen_pos = clampf(title_screen_pos, 0, 3)
		button_animation(title_screen_pos)
	if Input.is_action_just_pressed("title_interact"):
		if title_screen_pos == 0:
			$AnimationPlayer.play("exit_title")
		elif title_screen_pos == 1:
			$AudioStreamPlayer2D.play()
			#if Global.beat_game:
			get_tree().change_scene_to_file("res://scenes/title/level_select.tscn")
		elif title_screen_pos == 2:
			get_tree().quit()
	if title_screen_pos == 3:
		if Input.is_action_just_pressed("title_interact"):
			$AudioStreamPlayer2D.play()
		if Input.is_action_pressed("title_interact"):
			$Background3/AnimatedSprite2D.play("erasing progress")
			if $Background3/AnimatedSprite2D.frame == 12:
				erase_progress()
		if Input.is_action_just_released("title_interact"):
			$Background3/AnimatedSprite2D.play("erase")
			$Background3/AnimatedSprite2D.frame = 1

func button_animation(button_pos):
	if button_pos == -1:
		if title_pre_pos != button_pos:
			title_pre_pos = button_pos
			$Background3/AnimatedSprite2D.play("nothing")
	elif button_pos == 0:
		if title_pre_pos != button_pos:
			title_pre_pos = button_pos
			$Background3/AnimatedSprite2D.play("start")
	elif button_pos == 1:
		if title_pre_pos != button_pos:
			title_pre_pos = button_pos
			$Background3/AnimatedSprite2D.play("levels")
	elif button_pos == 2:
		if title_pre_pos != button_pos:
			title_pre_pos = button_pos
			$Background3/AnimatedSprite2D.play("exit")
	elif button_pos == 3:
		if title_pre_pos != button_pos:
			title_pre_pos = button_pos
			$Background3/AnimatedSprite2D.play("erase")

func start_game():
	print(Global.levels_beat)
	if Global.levels_beat[5] == true:
		get_tree().change_scene_to_file("res://scenes/mirror_cat_room.tscn")
	elif Global.levels_beat[4] == true:
		get_tree().change_scene_to_file("res://scenes/shop/shop.tscn")
	elif Global.levels_beat[3] == true:
		get_tree().change_scene_to_file("res://scenes/forest/forest_bottom_right.tscn")
	elif Global.levels_beat[2] == true:
		get_tree().change_scene_to_file("res://scenes/forest/forest.tscn")
	elif Global.levels_beat[1] == true:
		get_tree().change_scene_to_file("res://scenes/hallway/hallway.tscn")
	elif Global.levels_beat[0] == true:
		get_tree().change_scene_to_file("res://scenes/cat room/cat room.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/intro_game_cutscene.tscn")
	
func erase_progress():
	Global.talked_to_bruno = false

	Global.talked_to_Merryl = false

	Global.met_spamton = false

	Global.talked_to_spamton = false

	Global.spamton_escaped = false

	Global.talked_to_greg = false

	Global.broke_mirror = false

	Global.beat_game = false

	Global.levels_beat = [false, false, false, false, false, false]

	Global.entering_level_from_overworld = true
	
	get_tree().change_scene_to_file("res://scenes/title/intro.tscn")
