extends Node2D

var text_progression : int = 0

var text = ["\"It seems you were able to break free.\"", "\"How does it feel?\"", "\"Do you feel satisfied?\"", "\"Do you feel accomplished leaving us all here to pick up the slack?\"", "\"You know you'll be back.\"", "\"You can never escape your loop.\"", "\"You'll be back to your old ways again.\"", "\"Do you even care about the people you pretend to help?\"", "\"You'll be back, and I'll be waiting.\"", "\"Enjoy your freedom while it lasts.\"", "...", "Freedom."]

var text_voice = ["narrator", "narrator","narrator","narrator","narrator","narrator","narrator","narrator","narrator","narrator","narrator","player",]

signal show_button

signal hide_button

func _ready() -> void:
	$AnimatedSprite2D.play("bottom face button")
	$AnimatedSprite2D.modulate.a = 0.0
	$AnimatedSprite2D2.play("interact")
	$AnimatedSprite2D2.modulate.a = 0.0
	$RichTextLabel.visible_characters = 0
	$RichTextLabel.text = text[0]
	$Timer.wait_time = 0.08
	$Timer.paused = false
	$Timer.start()

func _process(delta: float) -> void:
	if Input.get_connected_joypads().size() > 0:
		$AnimatedSprite2D.visible = true
		$AnimatedSprite2D2.visible = false
	else:
		$AnimatedSprite2D.visible = false
		$AnimatedSprite2D2.visible = true
	if Input.is_action_just_pressed("interact") && $RichTextLabel.visible_ratio == 1:
		hide_button.emit()
		if text_progression == text.size() - 1:
			$AnimationPlayer.play("go_to_ending")
			return
		text_progression += 1
		$RichTextLabel.text = text[text_progression]
		$RichTextLabel.visible_characters = 0
		$Timer.paused = false
		$Timer.start()
	if Input.is_action_pressed("speed up"):
		$Timer.wait_time = 0.02
	else:
		$Timer.wait_time = 0.08

func _on_timer_timeout() -> void:
	if $RichTextLabel.visible_ratio == 1:
		show_button.emit()
		$Timer.paused = true
		return
	if $Timer.wait_time == 0.08 && ![" ", "\"", ",", ".", "!", "?"].has(str(text[text_progression][$RichTextLabel.visible_characters])):
		if text_voice[text_progression] == "narrator":
			$AudioStreamPlayer2D.play()
		elif text_voice[text_progression] == "player":
			pass
			#$AudioStreamPlayer2D.play()
	$RichTextLabel.visible_characters += 1
	
func go_to_ending():
	get_tree().change_scene_to_file("res://scenes/title/ending_cutscene_test.tscn")
