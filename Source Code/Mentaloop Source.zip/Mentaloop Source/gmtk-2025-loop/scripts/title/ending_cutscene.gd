extends Node2D

func _ready() -> void:
	$AnimationPlayer.play("ending cutscene")
	$AnimatedSprite2D.play("default")

func go_to_title():
	Global.beat_game = true
	get_tree().change_scene_to_file("res://scenes/title/title_screen.tscn")
