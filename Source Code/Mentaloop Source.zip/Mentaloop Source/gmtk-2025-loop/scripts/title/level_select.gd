extends Node3D

var title_screen_pos : int = 0

var title_pre_pos : int = 0

var title_screen_pos_y : int = 0

var title_pre_pos_y : int = 0

func _ready() -> void:
	$AnimationPlayer.play("enter_title")
	$Background3/levels.play("levels")
	$Background3/levels.pause()
	$Background3/levels.frame = 0
	$Background3/back.play("nothing")

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("move_down"):
			$AudioStreamPlayer2D.play()
			title_screen_pos_y += 1
			title_screen_pos_y = clampf(title_screen_pos_y, 0, 1)
	if Input.is_action_just_pressed("move_up"):
		$AudioStreamPlayer2D.play()
		title_screen_pos_y -= 1
		title_screen_pos_y = clampf(title_screen_pos_y, 0, 1)
	if title_pre_pos_y != title_screen_pos_y:
		title_pre_pos_y = title_screen_pos_y
		if title_screen_pos_y == 0:
			$Background3/back.play("nothing")
		elif title_screen_pos_y == 1:
			$Background3/back.play("back")
	if title_screen_pos_y == 1:
		$Background3/levels.frame = 0
		if Input.is_action_just_pressed("title_interact"):
			get_tree().change_scene_to_file("res://scenes/title/title_screen.tscn")
	else:
		if Input.is_action_just_pressed("move_right"):
			$AudioStreamPlayer2D.play()
			title_screen_pos += 1
			title_screen_pos = clampf(title_screen_pos, 1, 6)
		if Input.is_action_just_pressed("move_left"):
			$AudioStreamPlayer2D.play()
			title_screen_pos -= 1
			title_screen_pos = clampf(title_screen_pos, 1, 6)
		$Background3/levels.frame = title_screen_pos
		if title_pre_pos != title_screen_pos:
			title_pre_pos = title_screen_pos
		if Input.is_action_just_pressed("title_interact"):
			if title_screen_pos == 0:
				pass
			elif title_screen_pos >= 1:
				go_to_level_if_unlocked(title_screen_pos - 1)
func go_to_level_if_unlocked(level):
	print(Global.levels_beat[level])
	if Global.levels_beat[level]:
		Global.entering_level_from_overworld = false
		print("res://scenes/levels/level_" + str(level) + ".tscn")
		get_tree().change_scene_to_file("res://scenes/levels/level_" + str(level) + ".tscn")
