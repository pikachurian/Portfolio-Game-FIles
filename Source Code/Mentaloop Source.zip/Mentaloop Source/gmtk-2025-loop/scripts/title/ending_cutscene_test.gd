extends Node3D

func _ready() -> void:
	$AudioStreamPlayer3D.play()
