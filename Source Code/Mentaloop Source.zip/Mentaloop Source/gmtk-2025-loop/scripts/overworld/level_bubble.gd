extends AnimatedSprite3D

@export var level : int = 0

var player_touching : bool = false

func _ready() -> void:
	$Sprite3D.texture = load("res://assets/sprites/level bubbles/level " + str(level) + ".png")
	set_frame_and_progress(0, 0.0)
	set_speed_scale(1)

func _on_area_3d_body_entered(body: Node3D) -> void:
	player_touching = true
	play("default")
	set_speed_scale(1)
	print(level)

func _on_area_3d_body_exited(body: Node3D) -> void:
	player_touching = false
	play("default")
	set_frame_and_progress(5, 0.0)
	set_speed_scale(-1)
	
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("interact") && player_touching && frame == 5 && $Timer.is_stopped():
		visible = false
		$Timer.start()
		get_tree().get_first_node_in_group("overworld_player").start_level = true


#func _on_animation_finished() -> void:
	#print("Animation Finished.  Level: " + str(level))
	#$Sprite3D.texture = load("res://assets/sprites/level bubbles/level " + str(level) + ".png")
	#if frame == 4:
		#$Sprite3D.visible = true
	#else:
		#$Sprite3D.visible = false


func _on_frame_changed() -> void:
	if frame == 5:
		$Sprite3D.texture = load("res://assets/sprites/level bubbles/level " + str(level) + ".png")
		$Sprite3D.show = true
	else:
		$Sprite3D.show = false


func _on_timer_timeout() -> void:
	Global.entering_level_from_overworld = true
	Global.level = level
	get_tree().change_scene_to_file("res://scenes/transition_cutscene.tscn")
