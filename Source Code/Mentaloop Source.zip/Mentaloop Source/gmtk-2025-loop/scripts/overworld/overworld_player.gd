extends CharacterBody3D

var pre_pos : Vector3 = Vector3.ZERO

var player_direction = Vector2(0,-1)

var player_input_direction : Vector2 = Vector2.ZERO

var pre_dir : Vector2 = Vector2.ZERO

var walk_cooldown = 0

const SPEED : float = 0.7

var start_level = false

@export var cutscene : bool = false

@export var cutscene_sprite : Array = ["walk_forward", 1]

@onready var circle_transition = $CircleTransition

func _physics_process(delta: float) -> void:
	#print(Global.levels_beat)
	if start_level:
		$CollisionShape3D.disabled = true
		global_position.x = lerpf(global_position.x, -0.148, 0.1)
		global_position.y = lerpf(global_position.y, -0.724, 0.1)
		scale.x = lerpf(scale.x, 6.607, 0.1)
		scale.y = lerpf(scale.y, 6.607, 0.1)
		circle_transition.scale.x = lerpf(circle_transition.scale.x, 0.9, 0.1)
		circle_transition.scale.y = lerpf(circle_transition.scale.y, 0.9, 0.1)
		return
	if Input.is_action_just_pressed("title_back"):
		get_tree().change_scene_to_file("res://scenes/title/title_screen.tscn")
	if !cutscene:
		var input_direction = Vector2.ZERO
		input_direction = Input.get_vector("move_left", "move_right", "move_down", "move_up")
		input_direction.x = Input.get_axis("move_left", "move_right")
		input_direction.y = Input.get_axis("move_down", "move_up")
		player_input_direction = input_direction
		
		if input_direction != Vector2.ZERO:
			if pre_dir == input_direction:
				walk_cooldown = 15
			pre_dir = input_direction
			player_direction = input_direction
			
			if input_direction.x != 0:
				if input_direction.x > 0:
					$AnimatedSprite3D.play("walk_right")
					Global.player_last_direction = "right"
				elif input_direction.x < 0:
					$AnimatedSprite3D.play("walk_left")
					Global.player_last_direction = "left"
			else:
				if input_direction.y > 0:
					$AnimatedSprite3D.play("walk_backward")
					Global.player_last_direction = "back"
				elif input_direction.y < 0:
					$AnimatedSprite3D.play("walk_forward")
					Global.player_last_direction = "front"
		else:
			walk_cooldown -= 100 * delta
			if walk_cooldown <= 0:
				if player_direction.x > 0:
					$AnimatedSprite3D.play("idle_right")
				elif player_direction.x < 0:
					$AnimatedSprite3D.play("idle_left")
				elif player_direction.y > 0:
					$AnimatedSprite3D.play("idle_backward")
				elif player_direction.y < 0:
					$AnimatedSprite3D.play("idle_forward")
			else:
				$AnimatedSprite3D.pause()
	
		#print(input_direction)
		var speed_modifier = 1
		$AnimatedSprite3D.speed_scale = 1.0
		if Input.is_action_pressed("speed up"):
			speed_modifier = 1.4
			$AnimatedSprite3D.speed_scale = 1.4
		velocity.x = input_direction.x * SPEED * speed_modifier
		velocity.y = input_direction.y * SPEED * speed_modifier
	else:
		$AnimatedSprite3D.play(cutscene_sprite[0])
		$AnimatedSprite3D.set_frame_and_progress(cutscene_sprite[1], 0.0)
		velocity = Vector3.ZERO
		
	move_and_slide()
	if pre_pos.x == global_position.x && pre_pos.y == global_position.y && player_input_direction != Vector2.ZERO:
		if player_direction.x > 0:
			$AnimatedSprite3D.play("idle_right")
		elif player_direction.x < 0:
			$AnimatedSprite3D.play("idle_left")
		elif player_direction.y > 0:
			$AnimatedSprite3D.play("idle_backward")
		elif player_direction.y < 0:
			$AnimatedSprite3D.play("idle_forward")
	global_position.x = global_position.x
	pre_pos = global_position
	#print(global_position.y)
	
func start_cutscene():
	cutscene = true
	
func end_cutscee():
	cutscene = false

func start_level_cutscene():
	start_level = true
	$CollisionShape3D.disabled = true
	circle_transition.visible = true
