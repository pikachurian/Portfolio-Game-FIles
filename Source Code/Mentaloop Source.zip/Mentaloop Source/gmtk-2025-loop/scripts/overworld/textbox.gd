extends Node2D

signal finished_dialogue

var start_cooldown = 150

@export var text = ["text"]

var cur_text = ""

var character_count = 0

var textbox_state = "idle"

var textbox_list_pos = -1

@export var voice = "none"

func _ready() -> void:
	Global.textbox = true
	$AnimatedSprite2D2/AnimatedSprite2D.play("default")
	$AnimatedSprite2D2.play("default")
	modulate.a = 0
	next_line_of_text()
	
func _process(delta: float) -> void:
	#print(textbox_state)
	cur_text = text[textbox_list_pos]
	$HBoxContainer/VBoxContainer/RichTextLabel.text = cur_text
	if start_cooldown > 0:
		start_cooldown -= 1
	modulate.a = lerpf(modulate.a, 1, 0.1)
	if start_cooldown == 0:
		$Timer.start()
		start_cooldown = -1
		#if $HBoxContainer/VBoxContainer/RichTextLabel.visible_ratio == 1:
			#return
		#$HBoxContainer/VBoxContainer/RichTextLabel.visible_characters += 1
	if textbox_state == "waiting":
		if voice == "narrator_tutorial":
			if $TutorialTimer.is_stopped():
				if textbox_list_pos == text.size() - 1:
					Global.textbox = false
					finished_dialogue.emit()
					queue_free()
				else:
					textbox_state = "idle"
					next_line_of_text()
		else:
			if Input.is_action_just_pressed("interact"):
				if textbox_list_pos == text.size() - 1:
					Global.textbox = false
					finished_dialogue.emit()
					queue_free()
				else:
					textbox_state = "idle"
					next_line_of_text()
	else:
		if voice != "narrator_tutorial":
			if Input.is_action_pressed("speed up"):
				$Timer.wait_time = 0.01
			else:
				$Timer.wait_time = 0.04


func _on_timer_timeout() -> void:
	#print($HBoxContainer/VBoxContainer/RichTextLabel.visible_ratio)
	if $HBoxContainer/VBoxContainer/RichTextLabel.visible_ratio == 1:
		$TutorialTimer.start()
		textbox_state = "waiting"
		$Timer.paused = true
		return
	if $Timer.wait_time == 0.04 && ![" ", "\"", ",", ".", "!", "?", "-"].has(str(text[textbox_list_pos][$HBoxContainer/VBoxContainer/RichTextLabel.visible_characters])):
		if voice == "denial":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/denial_talk.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "anger":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/anger_talk.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "narrator":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/dialogue/narrator/typewriter.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "narrator_tutorial":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/dialogue/narrator/typewriter.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "bargin":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/bargin_talk.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "greg":
			$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/greg_talk.wav")
			$AudioStreamPlayer2D.play()
		elif voice == "none":
			pass
		elif voice == "bargin and anger":
			if textbox_list_pos == 1:
				$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/anger_talk.wav")
				$AudioStreamPlayer2D.play()
			else:
				$AudioStreamPlayer2D.stream = load("res://assets/sounds/overworld/bargin_talk.wav")
				$AudioStreamPlayer2D.play()
		else:
			pass
	$HBoxContainer/VBoxContainer/RichTextLabel.visible_characters += 1

func next_line_of_text():
	textbox_list_pos += 1
	cur_text = text[textbox_list_pos]
	$AnimationPlayer.play("textbox")
	$HBoxContainer/VBoxContainer/RichTextLabel.text = cur_text
	$HBoxContainer/VBoxContainer/RichTextLabel.visible_characters = 0
	$HBoxContainer/VBoxContainer/RichTextLabel.visible_ratio = 0
	$Timer.paused = false
	$Timer.start()

func _on_finished_dialogue():
	pass
