extends Sprite3D

var show : bool = false

func _process(delta: float) -> void:
	if show:
		#modulate.a = 0.5
		modulate.a = lerpf(modulate.a, 1, 0.1)
	else:
		#modulate.a = 0
		modulate.a = lerpf(modulate.a, 0, 0.1)
