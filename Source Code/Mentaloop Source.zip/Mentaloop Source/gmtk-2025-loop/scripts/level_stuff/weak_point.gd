extends LoopActor

#the id determines which weakpoint the player needs
#to target, starting with id 0
@export var id : int = 0

var is_damaged : bool = false
var is_target : bool = false

signal weak_point_hit

@onready var damage_particles : Array = $Area3D/DamageParticles.get_children()
@onready var animation_player = $AnimationPlayer
@onready var damage_particle = $Area3D/DamageParticles/DamageParticle
@onready var switch_damage_particle = $Area3D/DamageParticles/SwitchDamageParticle
@onready var player = get_tree().get_first_node_in_group("player")

@onready var fuzz_sound = $Area3D/Fuzz

func _ready():
	super._ready()
	if loop_side == -1:
		$Area3D.rotation.z = deg_to_rad(180)
	
func target() -> void:
	animation_player.play("target")
	is_target = true
	
func damage() -> void:
	if is_damaged == false && is_target == true:
		is_damaged = true
		is_target = false
		fuzz_sound.play()
		emit_signal("weak_point_hit")
		#for part in damage_particles:
		#	part.emitting = true
		if loop_side == 1:
			damage_particle.emitting = true
		else:
			switch_damage_particle.emitting = true
		animation_player.play("RESET")
		player.set_player_respawn()
