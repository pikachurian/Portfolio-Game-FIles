@tool
extends LoopActor

@export var sprite_texture : Texture2D = null :
	set(new_texture):
		sprite_texture = new_texture
		$Sprite3D.texture = new_texture

@export var is_silhouette : bool = false :
	set(new_is_silhouette):
		is_silhouette = new_is_silhouette
		if is_silhouette == true:
			$Sprite3D.modulate = Color("000000")
		else:
			$Sprite3D.modulate = Color("ffffff")

@onready var sprite_3d : Sprite3D = $Sprite3D
