extends LoopActor

func _ready():
	super._ready()
