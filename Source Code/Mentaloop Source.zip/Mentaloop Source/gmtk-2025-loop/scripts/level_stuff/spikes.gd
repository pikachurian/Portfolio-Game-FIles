extends LoopActor

func _ready():
	super._ready()
	if loop_side == -1:
		$Area3D.rotation.z = deg_to_rad(180)


func _on_area_3d_area_entered(area):
	pass
