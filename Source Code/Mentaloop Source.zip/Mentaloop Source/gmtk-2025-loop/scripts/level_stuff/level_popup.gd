extends LoopActor

enum InputAnimation {MOVEMENT, JUMP, MAP, GROUND_POUND}
@export var input_animation : InputAnimation = InputAnimation.MOVEMENT

@onready var controller_visuals = $ControllerVisuals
@onready var keyboard_visuals = $KeyboardVisuals

func _ready():
	super._ready()
	
	match input_animation:
		InputAnimation.MOVEMENT:
			set_input_animation("movement")
		InputAnimation.JUMP:
			set_input_animation("jump")
		InputAnimation.GROUND_POUND:
			set_input_animation("ground_pound")
		InputAnimation.MAP:
			set_input_animation("map")

func _physics_process(delta):
	if Input.get_connected_joypads().size() > 0:
		controller_visuals.visible = true
		keyboard_visuals.visible = false
	else:
		controller_visuals.visible = false
		keyboard_visuals.visible = true
		
		
func set_input_animation(animation_name : String) -> void:
	controller_visuals.play(animation_name)
	keyboard_visuals.play(animation_name)
