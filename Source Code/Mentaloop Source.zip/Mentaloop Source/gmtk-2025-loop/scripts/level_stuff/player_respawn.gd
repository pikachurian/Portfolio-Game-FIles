extends LoopActor

var dragon_progress_target : float = 0.0
var dragon_formation_on : int = 0
var dragon_formation_loops : int = 0
var dragon_progress_ratio : float = 0.0
