extends LoopActor

@export var weak_point_id : int = 0
@export var block_disappears : bool = false
@export var disappear_weak_point_id : int = 0

var is_active : bool = false

@onready var static_body_3d = $StaticBody3D
@onready var mesh_instance_3d = $StaticBody3D/MeshInstance3D
#@onready var player = get_tree().get_first_node_in_group("player")
@onready var snake_ground = get_tree().get_first_node_in_group("snake_ground")
@onready var spawn_particles = $SpawnParticles


func _ready():
	super._ready()
	
	snake_ground.weak_point_hit.connect(_on_weak_point_hit)
	static_body_3d.process_mode = Node.PROCESS_MODE_DISABLED
	mesh_instance_3d.visible = false


func _on_weak_point_hit(new_weak_point_id : int) -> void:
	if is_active == false && weak_point_id ==  new_weak_point_id:
		is_active = true
		static_body_3d.process_mode = Node.PROCESS_MODE_INHERIT
		mesh_instance_3d.visible = true
		
		if new_weak_point_id > 0:
			spawn_particles.emitting = true
			
	if block_disappears == true && is_active == true && disappear_weak_point_id == new_weak_point_id:
		is_active = false
		static_body_3d.process_mode = Node.PROCESS_MODE_DISABLED
		mesh_instance_3d.visible = false
		
		if new_weak_point_id > 0:
			spawn_particles.emitting = true
		
