@tool
extends LoopActor

enum Behavior {FOLLOW_PLAYER, STATIC}

#activates when the weak point with the matching
#id is targetd
@export var weak_point_id : int = 0
var is_active : bool = false

@export var turret_disappears : bool = false
@export var disappear_weak_point_id : int = 0

@export var behavior : Behavior = Behavior.FOLLOW_PLAYER

@export var size : float = 1.0

@onready var pupil_pivot = $Pivot/PupilPivot
@export_range(0, 360,10.0) var pupil_pivot_rotation : float = 0.0:
	set(new_pupil_rotation):
		pupil_pivot_rotation = new_pupil_rotation
		if pupil_pivot:
			pupil_pivot.global_rotation.z = deg_to_rad(pupil_pivot_rotation)

@export var bullet_scene : PackedScene = preload("res://scenes/bullets/basic_enemy_bullet.tscn")
@export var shoot_time : float = 1.0
var shoot_tick : float = 0.0
@export var bullet_speed : float = 5.0
@export var bullet_life_time : float = 3.0
@export var bullet_scale : float = 1.0


@onready var eye = $Pivot/Eye
@onready var camera = get_tree().get_first_node_in_group("camera")
@onready var player = get_tree().get_first_node_in_group("player")
@onready var bullet_parent = get_tree().get_first_node_in_group("bullet_parent")
@onready var snake_ground = get_tree().get_first_node_in_group("snake_ground")
@onready var animation_player = $Pivot/AnimationPlayer
@onready var pivot = $Pivot


func _ready():
	if Engine.is_editor_hint():
		return
		
	super._ready()
	
	pupil_pivot.global_rotation.z = deg_to_rad(pupil_pivot_rotation)
	pivot.scale *= size
	
	#billboard_sprite(eye)
	shoot_tick = shoot_time
	snake_ground.weak_point_hit.connect(_on_weak_point_hit)
	player.player_respawn_signal.connect(_on_player_respawn)
	animation_player.play("off")
	
func _physics_process(delta):
	if Engine.is_editor_hint():
		#pupil_pivot.global_rotation.z = pupil_pivot_rotation
		return
	
	if is_active == false:
		return
	
	if behavior == Behavior.FOLLOW_PLAYER:
		look_at_player()
	
	#shooting
	if shoot_tick <= 0:
		var bullet = bullet_scene.instantiate()
		bullet_parent.add_child(bullet)
		bullet.speed = bullet_speed
		bullet.life_time = bullet_life_time
		bullet.global_position = global_position
		bullet.scale.x = bullet_scale
		bullet.scale.y = bullet_scale
		shoot_tick = shoot_time
		bullet.point_towards(player.hit_box.global_position)
		shoot_tick = shoot_time
		
		if behavior == Behavior.STATIC:#こにちは。これはおもしろいい！
			bullet.global_rotation = pupil_pivot.global_rotation
	else:
		shoot_tick -= delta

func activate() -> void:
	if is_active == false:
		#is_active = true
		#print("AAAAA")
		animation_player.play("open")
		
func deactivate() -> void:
	if is_active == true:
		shoot_tick = shoot_time
		is_active = false#deactivate needs to stop being
		#active right away to prevent more bullet spawning
		
		#is_active = true
		#print("AAAAA")
		animation_player.play("close")
		
func set_is_active(value : bool) -> void:
	is_active = value

#make the eye follow the player
func look_at_player() -> void:
	var dir : Vector2 = Vector2(pupil_pivot.global_position.x, pupil_pivot.global_position.y).direction_to(Vector2(player.global_position.x, player.global_position.y))
	pupil_pivot.global_rotation.z = dir.angle()
	
func billboard_sprite(sprite : Sprite3D, reverse : bool = false) -> void:
	if reverse == false:
		sprite.look_at(camera.global_position)
	else:
		sprite.look_at(camera.global_position * Vector3(1,1,-1))
		
func _on_weak_point_hit(new_weak_point_id : int) -> void:
	if is_active == false && weak_point_id == new_weak_point_id:
		activate()
		
	if turret_disappears == true && is_active == true && disappear_weak_point_id == new_weak_point_id:
		deactivate()

func _on_player_respawn() -> void:
	shoot_tick = shoot_time
