extends Node3D

func _ready() -> void:
	Global.textbox = false
	$AnimationPlayer.play("enter_forest")

func exit_down():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest.tscn")

func exit_right():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_up_right.tscn")

func _on_area_3d_2_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_down")


func _on_area_3d_3_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_right")
