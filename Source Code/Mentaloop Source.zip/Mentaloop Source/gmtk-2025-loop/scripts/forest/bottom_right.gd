extends CanvasLayer

signal finished_dialogue

signal escape

signal grab_key

signal enable_collision

var child_text = ""

func _on_finished_dialogue():
	if child_text == "spamton":
		enable_collision.emit()
	elif child_text == "lockley":
		grab_key.emit()
	elif child_text == "escape":
		escape.emit()

func _on_enable_collision() -> void:
	pass # Replace with function body.

func _on_forest_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child_text = "not spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)

func _on_forest_2_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child_text = "not spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)

func _on_forest_3_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child_text = "not spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_forest_4_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child_text = "not spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_spamton_dialogue() -> void:
	#print("peekaboo!")
	$"../Music".stream_paused = true
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing ... wait..."]
	child_text = "spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_lockley_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "bargin"
	child.text = ["Hey ya!", "I see you're eyeying this KEY here.", "Well, if you want it, I can sell it to you for $25.", "What? You have no money?", "Then, no money, no key."]
	child_text = "lockley"
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_escape_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "bargin and anger"
	child.text = ["Well, the offer is still on the table-", "\"HHHRRRM! YOOOUUUUU!!!!\"", "Wuh.."]
	child_text = "escape"
	child.connect("finished_dialogue", _on_finished_dialogue)
	
func _on_grab_key() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*You got SHOP KEY!"]
	child_text = "not spamton"
	child.connect("finished_dialogue", _on_finished_dialogue)
