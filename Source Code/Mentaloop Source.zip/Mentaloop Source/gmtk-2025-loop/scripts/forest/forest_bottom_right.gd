extends Node3D

func _ready() -> void:
	Global.textbox = false
	if Global.levels_beat[2]:
		if Global.met_spamton:
			$spamton.queue_free()
		$Sprite3D.texture = load("res://assets/sprites/forest/forest bottom right.png")
	else:
		$spamton.queue_free()
	$AnimationPlayer.play("enter_forest")

func exit_up():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_up_right.tscn")

func exit_left():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest.tscn")

func _on_area_3d_2_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_up")


func _on_area_3d_3_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_left")

func meet_spamton():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	Global.met_spamton = true
	get_tree().change_scene_to_file("res://scenes/forest/forest_bottom_right.tscn")
	
func talk_to_spamton():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	Global.talked_to_spamton = true
	get_tree().change_scene_to_file("res://scenes/forest/forest_bottom_right.tscn")

func spamton_escaped():
	Global.spamton_escaped = true
