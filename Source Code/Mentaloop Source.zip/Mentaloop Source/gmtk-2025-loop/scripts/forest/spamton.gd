extends AnimatedSprite3D

func _ready() -> void:
	if Global.levels_beat[3]:
		if Global.spamton_escaped:
			queue_free()
		else:
			visible = true
			$"../Forest".queue_free()
			$"../Forest2".queue_free()
			$"../Forest3".queue_free()
			$"../Forest4".queue_free()
			$AnimatedSprite3D.queue_free()
			$Lockley.queue_free()
			play("rest")
	elif Global.talked_to_spamton:
		visible = true
		$Lockley.queue_free()
		$escape.queue_free()
		play("fire")
	else:
		if Global.met_spamton:
			visible = true
			play("default")
			$"../Forest".queue_free()
			$"../Forest2".queue_free()
			$"../Forest3".queue_free()
			$"../Forest4".queue_free()
			$escape.queue_free()
			$AnimatedSprite3D.queue_free()
		else:
			$Lockley.queue_free()
			$escape.queue_free()
			$StaticBody3D.queue_free()
			$AnimatedSprite3D.queue_free()
			visible = false
			play("default")
			


func _on_canvas_layer_grab_key() -> void:
	play("grab key")
	$"../GrabKey".play()
	$"../AnimationPlayer".play("grab key")


func _on_canvas_layer_escape() -> void:
	pause()
	$"../AnimationPlayer".play("SPAMTON ESCAPE")
