extends Node3D

func _ready() -> void:
	Global.textbox = false
	$AnimationPlayer.play("enter_forest")
	if Global.spamton_escaped:
		$LockedDoor.queue_free()
	else:
		$Area3D4.queue_free()

func exit_down():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_bottom_right.tscn")

func exit_left():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_up_left.tscn")
	
func exit_up():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/shop/shop.tscn")

func _on_area_3d_2_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_down")


func _on_area_3d_3_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_left")


func _on_area_3d_4_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_up")
