extends Node3D

func _ready() -> void:
	Global.textbox = false
	$AnimationPlayer.play("enter_forest")
	if Global.spamton_escaped == true:
		pass
	else:
		if Global.talked_to_Merryl:
			if Global.levels_beat[2]:
				$AudioStreamPlayer3D.play()
			else:
				pass
		else:
			$AudioStreamPlayer3D.play()
	#$AnimatedSprite3D.play("default")


func _on_area_3d_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_left")
	
func exit_left():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	if Global.talked_to_bruno:
		get_tree().change_scene_to_file("res://scenes/hallway/angry_hallway.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/hallway/hallway.tscn")
		
func exit_up():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_up_left.tscn")

func exit_right():
	Global.current_song = $Music.stream.resource_path
	Global.current_song_pos = $Music.get_playback_position()
	get_tree().change_scene_to_file("res://scenes/forest/forest_bottom_right.tscn")

func _on_area_3d_2_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_up")


func _on_area_3d_3_body_entered(body: Node3D) -> void:
	$AnimationPlayer.play("exit_right")
	
func angry_triangle():
	Global.talked_to_Merryl = true
	get_tree().change_scene_to_file("res://scenes/forest/forest.tscn")
