extends CanvasLayer

signal finished_dialogue

signal enable_collision

func _on_finished_dialogue():
	enable_collision.emit()

func _on_enable_collision() -> void:
	pass # Replace with function body.

func _on_forest_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_a_tree_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*A big, majestic, healthy, Douglas fir."]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_a_1_up_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*nothing - ooh, hey a mushroom!"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_forest_2_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.text = ["*nothing"]
	child.connect("finished_dialogue", _on_finished_dialogue)


func _on_locked_door_dialogue() -> void:
	var child = load("res://scenes/overworld/textbox.tscn").instantiate()
	add_child(child)
	child.voice = "narrator"
	child.text = ["*It's locked.", "There seems to be someone sad inside."]
	child.connect("finished_dialogue", _on_finished_dialogue)
