extends AnimatedSprite3D

func _ready() -> void:
	if Global.spamton_escaped == true:
		$AnimatedSprite3D.queue_free()
		$"../TriangeGirl".queue_free()
		$"../LessAngryTriangeGirl".queue_free()
		queue_free()
	else:
		if Global.talked_to_Merryl:
			if Global.levels_beat[2]:
				play("less angry")
				$AnimatedSprite3D.queue_free()
				$"../TriangeGirl".queue_free()
			else:
				play("fire")
				$"../LessAngryTriangeGirl".queue_free()
				$"../TriangeGirl".queue_free()
		else:
			play("default")
			$AnimatedSprite3D.queue_free()
			$"../LessAngryTriangeGirl".queue_free()
