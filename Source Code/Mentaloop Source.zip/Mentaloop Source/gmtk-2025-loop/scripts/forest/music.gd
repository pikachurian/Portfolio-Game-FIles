extends AudioStreamPlayer3D

func _ready() -> void:
	if Global.levels_beat[3] && Global.spamton_escaped:
		stream = load("res://assets/songs/Room1_theme.wav")
	elif Global.met_spamton:
		stream = load("res://assets/songs/Spamton_overworld.wav")
	else:
		stream = load("res://assets/songs/Room1_theme.wav")
	if str(Global.current_song) == str(stream.resource_path):
		play(Global.current_song_pos)
	else:
		play()
