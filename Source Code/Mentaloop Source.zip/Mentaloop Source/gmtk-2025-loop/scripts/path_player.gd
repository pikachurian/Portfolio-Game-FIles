extends PathFollow3D

var move_speed : float = 5.0
var jump_speed : float = 15
var gravity : float = 50

var is_grounded : bool = false

var custom_velocity : Vector3 = Vector3.ZERO
var progress_delta : float = 0.0

#camera stuff
var my_rotation : float = 0.0
var move_camera_to_player : bool = false
var camera_follow_lerp_alpha : float = 0.03#0.05
var camera_start_follow_dist : float = 1.0
var camera_end_follow_dist : float = 0.8#0.1

#var camera_follow_angle_speed : float = 1

#collisions
var area_colliding : bool = false

var sprite_dir : int = 1
var just_landed : bool = false

@onready var camera : Camera3D = get_tree().get_first_node_in_group("camera")
@onready var sprite : AnimatedSprite3D = $CharacterBody3D/AnimatedSprite3D
@onready var character = $CharacterBody3D
@onready var camera_target = $CameraTarget
@onready var collision_area = $CharacterBody3D/CollisionArea


func _ready():
	my_rotation = rotation.x

func _physics_process(delta):
	#just_landed = false
	var prev_rotation : float = rotation.x
	
	#update grounded
	if character.position.y <= 0.1:
		if is_grounded == false:
			is_grounded = true
			#just_landed = true
			sprite.play("land")
	else:
		is_grounded = false
	
	#update gravity
	if !is_grounded:
		custom_velocity.y -= gravity * delta
	else:
		custom_velocity = Vector3.ZERO
	
	#walking
	var h_input : float = Input.get_axis("move_left", "move_right")
	#progress += h_input * move_speed * delta
	progress_delta = h_input * move_speed * delta
	
	#for camera
	if Input.is_action_pressed("move_left"):
		my_rotation -= abs(rotation.x - prev_rotation)
	else:
		my_rotation += abs(rotation.x - prev_rotation)
	
	
	#jumping
	if is_grounded && Input.is_action_just_pressed("jump"):
		custom_velocity.y = jump_speed
		sprite.play("jump")
		
	#collisions
	var og_progress : float = progress
	progress += progress_delta
	
	if collision_area.has_overlapping_bodies():
		progress -= progress_delta * 4
		
	print(character.position)
	
	character.translate(custom_velocity * delta)
	
	#camera movement
	update_camera(delta)
	
	#update sprite dir
	if h_input != 0:
		sprite_dir = sign(h_input)
	
	#animation
	#update_animation(h_input)
	if sprite_dir == 1:
		sprite.flip_h = false
	else:
		sprite.flip_h = true
		
	if sprite.animation != "jump":
			if h_input:
				sprite.play("run")
			elif sprite.animation == "land":
				if sprite.frame_progress == 1.0:
					sprite.play("idle")
			else:
				sprite.play("idle")
	
		
func update_animation(h_input : float) -> void:
	if sprite_dir == 1:
		sprite.flip_h = false
	else:
		sprite.flip_h = true
		
	sprite.play(choose_animation(h_input))
	
func choose_animation(h_input : float) -> String:
	
	
	if just_landed:
		return "land"
		
	if !is_grounded:
		return "jump"
	
	if h_input:
		return "run"
		
	return "idle"

func update_camera(delta : float) -> void:
	#camera.global_position.x = lerp(camera.global_position.x, -camera_target.global_position.z, 0.1)
	camera.global_position.x = lerp(camera.global_position.x, camera_target.global_position.x, 0.1)
	camera.global_position.y = lerp(camera.global_position.y, camera_target.global_position.y, 0.1)
	
	#camera movement
	#if move_camera_to_player == false && abs(my_rotation - camera.rotation.z) >= camera_start_follow_dist:
		##move_camera_to_player = true
	#
	#if move_camera_to_player:
		#camera.rotation.z = lerp(camera.rotation.z, my_rotation, camera_follow_lerp_alpha)
		#if abs(my_rotation - camera.rotation.z) <= camera_end_follow_dist:
			#move_camera_to_player = false
	#camera.global_rotation.z = lerp(camera.global_rotation.z, camera_target.global_rotation.z, camera_follow_lerp_alpha)
	#camera.transform.basis.z = camera_target.transform.basis.z
	
	camera.global_rotation.z = camera_target.global_rotation.z
	#var rot_dir : float = sign(camera_target.global_rotation.z - camera.global_rotation.z)
	#camera.global_rotation.z += rot_dir * camera_follow_angle_speed * delta
		
func billboard() -> void:
	sprite.look_at(camera.global_position)


func _on_collision_area_body_entered(body):
	area_colliding = true


func _on_collision_area_body_exited(body):
	area_colliding = false
