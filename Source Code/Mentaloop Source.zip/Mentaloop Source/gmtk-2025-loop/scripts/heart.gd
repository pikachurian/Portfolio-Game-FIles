extends TextureRect

@export var heart_i : int = 0

var animation_i : int = 0

func _process(delta):
	texture = load("res://assets/svg/gui/hearts/heart" + str(floori(fmod(float(animation_i) * 0.03 + float(heart_i), 3))) + ".svg")
	animation_i += 1
