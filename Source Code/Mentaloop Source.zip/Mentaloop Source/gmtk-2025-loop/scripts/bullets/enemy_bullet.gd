extends Node3D

class_name EnemyBullet

@export var speed : float = 10.0
@export var life_time : float = 3.0

func _physics_process(delta):
	life_time -= delta
	if life_time <= 0.0:
		queue_free()

func point_towards(target : Vector3) -> void:
	var dir : Vector2 = Vector2(global_position.x, global_position.y).direction_to(Vector2(target.x, target.y))
	global_rotation.z = dir.angle()

func update_movement(delta) -> void:
	global_translate(global_transform.basis.x * speed * delta)
