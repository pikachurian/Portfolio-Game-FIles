extends EnemyBullet

func _physics_process(delta):
	super._physics_process(delta)
	update_movement(delta)
