extends PathFollow3D
class_name LoopActor

var progress_ratio_offset : float = 0.0

#1 = inner, -1 = outer, 0 = transition/limbo/between
@export var loop_side : int = 1

#@export var weak_point_id : int = 0

func _ready():
	progress_ratio_offset = progress_ratio
	
