extends Path3D

const SEGMENT_SCENE = preload("res://scenes/dragon/segment.tscn")
const DRAGON_HEAD_SCENE = preload("res://scenes/dragon/dragon_head.tscn")
const DRAGON_PATTERN_SCENE = preload("res://scenes/dragon/dragon_pattern.tscn")
const DRAGON_HAND_SCENE = preload("res://scenes/dragon/dragon_hand.tscn")

@export var overworld_scene : String = ""
@export var level_to_beat : int = 0

@export var total_segments = 10
@export var pattern_count : int = 10
@export var pattern_offset : float = 0.9
@export var head_progress_ratio : float = 1.0

var dragon_head = null
var dragon_hands = []

#the various progress_ratio values the dragon loops through when hurt
@export var dragon_formations : Array[float] = [
	0.0,
	0.25,
	0.5,
	0.75
]
@export var dragon_formation_on : int = 0
var dragon_progress_target : float = 0.0
var dragon_progress_ratio : float = 0.0
var dragon_formation_loops : int = 0

@export var dragon_rotate_speed : float = 5.0#0.005 # 0.001

#audio
@export var songs : Array[AudioStreamWAV] = []

var audio_players : Array[AudioStreamPlayer] = []

#weakpoints
var weak_points : Array = []
var weak_point_on : int = -1

signal weak_point_hit(new_weak_point_id : int)
signal level_beaten

@onready var player = get_tree().get_first_node_in_group("player")
@onready var camera : Camera3D = get_tree().get_first_node_in_group("camera")
@onready var bullets = $Bullets

func _ready():
	generate_segments(total_segments)
	generate_head(head_progress_ratio)
	generate_pattern(pattern_count, pattern_offset)
	generate_hand(0.95)
	generate_hand(0.93)
	
	generate_hand(0.55)
	generate_hand(0.53)
	
	if dragon_formations.size() > 0:
		dragon_progress_target = dragon_formations[dragon_formation_on]
	
	player.finished_ground_pound.connect(_on_player_ground_pound)
	player.player_died.connect(_on_player_died)
	player.player_respawn_signal.connect(_on_player_respawn)
	camera.fade_out_finished.connect(_on_fade_out_finished)
	
	#add weekpoints to array
	for child in get_children():
		if child.is_in_group("weak_point"):
			weak_points.append(child)
			child.weak_point_hit.connect(_on_weak_point_hit)
			
	#sort weak points based on id
	var n : int = weak_points.size()
	for i in n:
		var min_index : int = i
		
		for j in range(i + 1, n):
			if weak_points[j].id < weak_points[min_index].id:
				min_index = j
		
		var temp = weak_points[i]
		weak_points[i] = weak_points[min_index]
		weak_points[min_index] = temp
	
	
	#add audio players
	for song in songs:
		var p = AudioStreamPlayer.new()
		add_child(p)
		audio_players.append(p)
		if song != null:
			p.stream = song
		p.bus = "Music"
		p.play()
		p.volume_db = -80.0
	
	#select weekpoint target
	#weak_points[weak_point_on].target()
	_on_weak_point_hit()
	

func _physics_process(delta):
	if dragon_progress_ratio < dragon_progress_target:
		rotate_dragon(delta, dragon_rotate_speed / 100)
		if dragon_progress_ratio > dragon_progress_target:
			var target_change : float = dragon_progress_target - dragon_progress_ratio
			rotate_dragon(delta, target_change / 100)
	#rotate_dragon(delta, 0.001)
	
func go_to_next_formation() -> void:
	if dragon_formations.size() < 1:
		return
		
	dragon_formation_on += 1
	if dragon_formation_on >= dragon_formations.size():
		dragon_formation_on = 0
		dragon_formation_loops += 1
		
	dragon_progress_target = dragon_formations[dragon_formation_on] + 1.0 * dragon_formation_loops
	
func set_dragon_rotation_progress(delta : float, dragon_progress : float):
	for child in get_children():
		if child.is_in_group("dragon_object"):
			child.progress_ratio = dragon_progress + child.progress_ratio_offset

	#move player
	if player.on_dragon == true:
		player.progress_ratio = dragon_progress + player.dragon_progress_ratio_offset
		player.push_out_of_walls(delta, player.left_rays)
		player.push_out_of_walls(delta, player.right_rays)

func rotate_dragon(delta : float, amount : float) -> void:
	for child in get_children():
		if child.is_in_group("dragon_object"):
			child.progress_ratio += amount * delta
			
	#move player
	if player.on_dragon == true:
		player.progress_ratio += amount * delta
		player.push_out_of_walls(delta, player.left_rays, false)
		player.push_out_of_walls(delta, player.right_rays, true)
		
	dragon_progress_ratio += amount *  delta

func generate_hand(progress_ratio : float) -> void:
	dragon_hands.push_front(DRAGON_HAND_SCENE.instantiate())
	add_child(dragon_hands[0])
	dragon_hands[0].set_progress_ratio(progress_ratio)
	
	dragon_hands[0].progress_ratio_offset = dragon_hands[0].progress_ratio

func generate_head(progress_ratio : float = 1.0) -> void:
	dragon_head = DRAGON_HEAD_SCENE.instantiate()
	add_child(dragon_head)
	dragon_head.set_progress_ratio(progress_ratio)
	dragon_head.progress_ratio_offset = dragon_head.progress_ratio

func generate_segments(num_of_sprites : int) -> void:
	for i in range(num_of_sprites):
		var seg : PathFollow3D = SEGMENT_SCENE.instantiate()
		add_child(seg)
		seg.set_progress_ratio(i * (1.0 / (num_of_sprites)))
		seg.progress_ratio_offset = seg.progress_ratio
		
func generate_pattern(pattern_count : int, offset : float) -> void:
	for i in range(pattern_count):
		var pat : PathFollow3D = DRAGON_PATTERN_SCENE.instantiate()
		add_child(pat)
		var ratio = (i * (1.0 / (pattern_count)))
		#ratio = fmod(ratio, 1.0)
		
		pat.set_progress_ratio(ratio)
		pat.progress += offset
		
		pat.progress_ratio_offset = pat.progress_ratio
	
func end_level() -> void:
	print("Yay you won!")
	#get_tree().change_scene_to_file(overworld_scene)
	emit_signal("level_beaten")
	#go_to_overworld()
	
func go_to_overworld() -> void:
	if Global.entering_level_from_overworld:
		get_tree().change_scene_to_file(overworld_scene)
		Global.levels_beat[level_to_beat] = true
	else:
		get_tree().change_scene_to_file("res://scenes/title/level_select.tscn")
	
func clear_bullets() -> void:
	for bullet in bullets.get_children():
		bullet.queue_free()
	
func _on_player_ground_pound() -> void:
	go_to_next_formation()
	
func _on_player_died() -> void:
	clear_bullets()
		
func _on_player_respawn() -> void:
	clear_bullets()
	
func _on_weak_point_hit() -> void:
	if weak_point_on >= 0:
		audio_players[weak_point_on].volume_db = -80.0
	
	weak_point_on += 1
	
		
	if weak_point_on < weak_points.size():
		weak_points[weak_point_on].target()
		emit_signal("weak_point_hit", weak_point_on)
		#audio
		audio_players[weak_point_on].volume_db = 0.0
	else:
		end_level()
		
func _on_fade_out_finished() -> void:
	go_to_overworld()
