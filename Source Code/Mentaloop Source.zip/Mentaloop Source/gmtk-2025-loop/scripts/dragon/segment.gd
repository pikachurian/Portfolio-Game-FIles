extends LoopActor

class_name Segment

@export var disperse_speed : float = 5.0
var sprite : Sprite3D = null
var level_beaten : bool = false
@onready var camera : Camera3D = get_tree().get_first_node_in_group("camera")

@onready var snake_ground : Path3D = get_tree().get_first_node_in_group("snake_ground")

func _ready():
	super._ready()
	sprite = $Sprite3D
	camera = get_tree().get_first_node_in_group("camera")
	billboard_sprite(sprite)
	snake_ground.level_beaten.connect(_on_level_beaten)
	
func _physics_process(delta):
	if level_beaten:
		translate(-transform.basis.z * disperse_speed * delta)

#func billboard(reverse : bool = false) -> void:
	#if reverse == false:
		#sprite.look_at(camera.global_position)
	#else:
		#sprite.look_at(camera.global_position * Vector3(1,1,-1))

func billboard_sprite(sprite : Sprite3D, reverse : bool = false) -> void:
	if reverse == false:
		sprite.look_at(camera.global_position)
	else:
		sprite.look_at(camera.global_position * Vector3(1,1,-1))
		
func _on_level_beaten() -> void:
	if level_beaten == false:
		level_beaten = true
		reparent(snake_ground.get_parent())
		var x : float = randf_range(0, TAU)
		var y : float = randf_range(0, TAU)
		var z : float = randf_range(0, TAU)
		rotation = Vector3(x, y, z)
	
