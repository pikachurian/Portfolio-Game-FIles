extends Segment

@onready var wave_offset : float = randf_range(-0.2,0.2)

func _ready():
	sprite = $Sprite3D
	billboard_sprite(sprite, true)
	
func _physics_process(delta):
	rotation.x = Global.wave(-0.6, 0.6, 0.008, wave_offset)
