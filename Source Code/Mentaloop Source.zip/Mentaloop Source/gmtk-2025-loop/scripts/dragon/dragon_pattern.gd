extends Segment
