extends Segment

@onready var head = $Head
@onready var pupil = $Head/PupilPivot/Pupil
@onready var pupil_pivot = $Head/PupilPivot
@onready var player = get_tree().get_first_node_in_group("player")
@onready var animation_player = $AnimationPlayer

var target_pupil_rotation : float = 0

func _ready():
	billboard_sprite(head, true)
	target_pupil_rotation = pupil_pivot.rotation.z
	player.finished_ground_pound.connect(_on_player_ground_pound)
	animation_player.play("RESET")
	
	
func _physics_process(delta):
	look_at_player()
	
	#billboard_sprite(head, true)
	
	#end animations if animation finished
	if animation_player.current_animation != "RESET"\
			&& animation_player.current_animation_position >= animation_player.current_animation_length:
		animation_player.play("RESET")
		

func look_at_player():
	var dir : Vector2 = Vector2(pupil_pivot.global_position.x, pupil_pivot.global_position.y).direction_to(Vector2(player.global_position.x, player.global_position.y))
	#target_pupil_rotation = dir.angle()
	#pupil_pivot.global_rotation.z = lerp(pupil_pivot.global_rotation.z, target_pupil_rotation, 0.1)
	pupil_pivot.global_rotation.z = dir.angle()

func _on_player_ground_pound() -> void:
	animation_player.play("hurt")
