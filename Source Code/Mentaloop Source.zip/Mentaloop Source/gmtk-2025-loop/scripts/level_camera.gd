extends Camera3D

signal fade_out_finished

@onready var snake_ground = get_tree().get_first_node_in_group("snake_ground")
@onready var animation_player = $AnimationPlayer
#onready var leave_level_sound = $LeaveLevel

func _ready():
	snake_ground.level_beaten.connect(_on_level_beaten)

func emit_fade_out_finished() -> void:
	emit_signal("fade_out_finished")
	
func _on_level_beaten() -> void:
	animation_player.play("fade_out")
	#leave_level_sound.play()

func player_gameover():
	animation_player.play("fade_out_restart")

func restart():
	get_tree().reload_current_scene()
